/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bucles;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author alexisfuentes
 */
public class Periodica {
       static Elemento tmp;
    static Elemento tmp_ant;
    public static void main(String[] args) {
        // TODO code application logic here
        ArrayList<Elemento> elementos= new ArrayList();
        Scanner scan;
        scan = new Scanner(System.in);
        System.out.println("Ingrese la cantidad de elementos");
        int n = scan.nextInt();
        for(int i=0; i<n; i++) {
            Elemento e= new Elemento();
            System.out.println("Ingrese el nombre");
            e.nombre=scan.next();
            System.out.println("");
             System.out.println("Ingrese la conductividad termica");
            e.condutividadter =scan.nextFloat();
            System.out.println("");
            System.out.println("Ingrese la conductividad electica");
            e.condutividadele =scan.nextFloat();
            elementos.add(e);
        }
        
        tmp= elementos.get(0);//primer elemento
        int mayor_i =0;//posicion del elemnto que tenga 
       while(true)
       {
           elementos.forEach((Elemento item)->{//cuando no se sabe cuantos elemntos tiene un for
               //devuelve cda elemnto del arreglo sin importar la posicion
               //devuelve una funcion anonima
            if(item.condutividadele > tmp.condutividadele){
                tmp_ant =tmp; //guarda el valor anterior que tenia tmp si vale 20
                tmp= item;//encuentra un  nuevo valor de 30.5
            }
           });
           System.out.println(tmp.condutividadele);
           System.out.println(tmp.nombre);
           break;
       }
    }
}
