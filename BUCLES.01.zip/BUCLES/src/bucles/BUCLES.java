/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bucles;

import java.awt.Color;
import java.awt.Graphics;
import java.util.Scanner;
import javax.swing.JApplet;
import javax.swing.JOptionPane;

/**
 *
 * @author alexisfuentes
 */
public class BUCLES extends JApplet{

       public static void main ( String args[])
{
        
        
      String  n1,n2,n3,n4;
      int num1,num2,num3,num4,menor,medio,mayor;
    
        n1 = JOptionPane.showInputDialog( "Ingrese el primer numero " );
        n2 = JOptionPane.showInputDialog( "Ingrese el segundo numero " );
        n3 = JOptionPane.showInputDialog( "Ingrese el tercer numero" );
     
      num1 = Integer.parseInt(n1);
      num2 = Integer.parseInt( n2 );
      num3 = Integer.parseInt( n3 );
      
   if((num1<=num2)&&(num1<=num3)){
       menor = num1;
       
       if(num2<=num3){
           medio=num2;
           mayor=num3;
       }else{
           medio=num3;
           mayor=num2;
       }
   }else if((num2<=num1)&&(num2<num3)){
       menor=num2;
       
       if(num1<=num3){
           medio=num1;
           mayor=num3;
       }else{
           medio=num3;
           mayor=num1;
       }
   }else{
   menor=num3;
   
   if(num1<=num2){
           medio=num1;
           mayor=num2;
       }else{
           medio=num2;
           mayor=num1;
       }
   }
      
      JOptionPane.showMessageDialog ( null," "+mayor+" "+medio+" "+menor);

}
}
