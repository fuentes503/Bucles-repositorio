/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package bucles;

import java.io.PrintStream;
import java.util.Scanner;
import javax.swing.JOptionPane;

/*Una tienda ha puesto en oferta la venta de un producto, ofreciendo 15% de descuento por la
compra de 3 docenas y 10% en caso contrario. Además por la compra de más de 3 docenas se
obsequia una unidad por cada docena en exceso sobre 3. Diseñe un programa que determine
el monto de la compra, el monto de descuento y el número de unidades de obsequio para
cada uno de los 10 clientes que se atendieron en el día./*
/**
 *
 * @author alexisfuentes
 */
public class Descuentos {
        public static void main ( String args[])
 {
     String valor,cantidad;
    int cant,unidades = 0,totall=0;
    double total = 0;
    double val,compra = 0;
     String array[]=new String [3];
     String aux;
     Scanner stdin=new Scanner (System.in);
     for(int i=0;i<array.length;i++){
 
    //valor=JOptionPane.showInputDialog("Ingrese el valor del producto");
   // val=Double.parseDouble(valor);
   System.out.println("precio de producto");
   val=stdin.nextDouble();
   System.out.println("cantidad de unidades de producto del cliente:"+i++);
   cant=stdin.nextInt();
    Double descuento=0.0;
    compra=val*cant;
    if(cant==36){
        descuento=(compra*0.15);

    }
    if(cant<=35){
        descuento= (compra*0.10);

    }
    if(cant>=37){
        int undidades = 0;
                undidades= cant/36;
                 totall=undidades*1;

    }
    System.out.println("monto de compra "+compra+"  para el cliente "+i);
    System.out.println("monto de descuento "+descuento+"   para el cliente "+i);
    System.out.println("unidades de descuento "+totall+"  para el cliente "+i);
    System.out.println("\n");
     
     }
 }
    
}
