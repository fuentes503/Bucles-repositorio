/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bucles;

import javax.swing.JOptionPane;

/**
 *
 * @author alexisfuentes
 */
public class Peso_altura {
          public static void main ( String args[])
{
        String peso,altura = null;
        double Peso = 0,Altura = 0,PromAtl = 0,PromPeso=0;
        String opcion;
        char opc = 0;
        int temp = 0,personas=0;
        String total;
       
       total=JOptionPane.showInputDialog("Ingrese total de persona");
        personas=Integer.parseInt(total);
        for(int i=1;i<=personas;i++){
        peso=JOptionPane.showInputDialog(null,"ingrese peso de la persona  "+i );
        Peso=Double.parseDouble(peso);
        altura=JOptionPane.showInputDialog(null,"ingrese altura de la persona  "+i );
        Altura=Double.parseDouble(altura);
        PromPeso=PromPeso+Peso/personas;
        PromAtl=PromAtl+Altura/personas;
        }
     
          JOptionPane.showMessageDialog(null,"Peso promedio: "+PromPeso);
          JOptionPane.showMessageDialog(null,"Altura promedio: "+PromAtl);
    

 }
}
