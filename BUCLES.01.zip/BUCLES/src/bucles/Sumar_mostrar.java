/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bucles;

/**
 *
 * @author alexisfuentes
 */
public class Sumar_mostrar {
       
        public static void main ( String args[])
 {
      /*  int array[]={2, 5, 7, 10, 12, 15, 17,1800};
        int total=0;
        for(int contador=0;contador<array.length;contador++){
            total+=array[contador];
        }
        System.out.println("La suma del vector es: "+total);
        for(int elemento:array)
        System.out.println(elemento);*/
     int total=0;
     int suma1=0;
     int array[]=new int[1795];
     for(int contador=0;contador<=array.length;contador++){
      suma1=contador+2;
      System.out.println("suma del arreglo es: "+suma1);
      suma1=suma1+3;
      System.out.println("suma del arreglo es: "+suma1);
      total+=suma1;
     }
      System.out.println("suma del arreglo es: "+total);
     
 }
}