/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bucles;

import javax.swing.JOptionPane;

/*Una compañía dedicada al alquiler de automóviles cobra $30.00 hasta un máximo de 300 Km
de distancia recorrida. Para más de 300 y hasta 1000 Km cobra $30.00 más un monto
adicional de $0.15 por cada Kilómetro en exceso sobre 300. Para más de 1000 Km cobra $30
más un monto de $0.10 por cada Kilómetro en exceso de 1000. Diseñe un programa que
calcule el monto a pagar por cada automóvil cobrado en un día de trabajo.*/
/**
 *
 * @author alexisfuentes
 */
public class Renta_vehiculos {
    
  public static void main ( String args[])
{
        
   int opc;
   double pago3,pago2,pago,mil;
   double monto,kilometros;
    String pag,mon,km;
    do{
        km= JOptionPane.showInputDialog("Ingrese el recorrido");
        kilometros=Integer.parseInt(km);
        if(kilometros<=300){
            JOptionPane.showMessageDialog(null,"total a pagar $:"+30);
            
        }if(kilometros>300 && kilometros<1000){
            pago=kilometros-300;
            pago2=30+(pago*0.15);
            JOptionPane.showMessageDialog(null,"total a pagar $:"+pago2);
          
        }if(kilometros>1000){
            mil=kilometros-1000;
            pago3=30+(mil*0.10);
            JOptionPane.showMessageDialog(null,"total a pagar $:"+pago3);
            
        }
    JOptionPane.showMessageDialog(null,"digita 1 para calcular monto");
    JOptionPane.showMessageDialog(null,"digita 0 para salir ");
   String aux= JOptionPane.showInputDialog("Ingrese una opcion");
    
    opc=Integer.parseInt(aux);
}while(opc==1);
    
 }

}